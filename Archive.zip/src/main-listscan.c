#include "zorpinvader.h"
#include "util-logger.h"
#include "crypto-blackrock.h"


void
main_listscan(struct ZorpInvader *zorpinvader)
{
    uint64_t i;
    uint64_t range;
    uint64_t start;
    uint64_t end;
    struct BlackRock blackrock;
    unsigned increment = zorpinvader->shard.of;
    uint64_t seed = zorpinvader->seed;

    /* If called with no ports, then create a pseudo-port needed
     * for the internal algorithm. */
    if (!massip_has_target_ports(&zorpinvader->targets))
        rangelist_add_range(&zorpinvader->targets.ports, 80, 80);
    massip_optimize(&zorpinvader->targets);

    /* The "range" is the total number of IP/port combinations that
     * the scan can produce */
    range = massip_range(&zorpinvader->targets).lo;


infinite:
    blackrock_init(&blackrock, range, seed, zorpinvader->blackrock_rounds);

    start = zorpinvader->resume.index + (zorpinvader->shard.one-1);
    end = range;
    if (zorpinvader->resume.count && end > start + zorpinvader->resume.count)
        end = start + zorpinvader->resume.count;
    end += (uint64_t)(zorpinvader->retries * zorpinvader->max_rate);

    for (i=start; i<end; ) {
        uint64_t xXx;
        unsigned port;
        ipaddress addr;

        xXx = blackrock_shuffle(&blackrock,  i);

        massip_pick(&zorpinvader->targets, xXx, &addr, &port);
        

        if (zorpinvader->is_test_csv) {
            /* [KLUDGE] [TEST]
             * For testing randomness output, prints last two bytes of
             * IP address as CSV format for import into spreadsheet
             */
            printf("%u,%u\n",(addr.ipv4>>8)&0xFF, (addr.ipv4>>0)&0xFF);
        } else if (zorpinvader->targets.count_ports == 1) {
            ipaddress_formatted_t fmt = ipaddress_fmt(addr);
            /* This is the normal case */
            printf("%s\n", fmt.string);
        } else {
            ipaddress_formatted_t fmt = ipaddress_fmt(addr);
            if (addr.version == 6)
                printf("[%s]:%u\n", fmt.string, port);
            else
                printf("%s:%u\n", fmt.string, port);
        }

        i += increment; /* <------ increment by 1 normally, more with shards/NICs */
    }

    if (zorpinvader->is_infinite) {
        seed++;
        goto infinite;
    }
}
