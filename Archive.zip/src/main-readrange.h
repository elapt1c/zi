#ifndef MAIN_READRANGE_H
#define MAIN_READRANGE_H
struct ZorpInvader;

void
main_readrange(struct ZorpInvader *zorpinvader);

#endif
