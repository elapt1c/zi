/*
    ZorpInvader scripting subsystem
*/
#ifndef SCRIPTING_H
#define SCRIPTING_H
#include "proto-banner1.h"
struct ZorpInvader;

extern const struct ProtocolParserStream banner_scripting;

/**
 * Load the Lua scripting library and run the initialization
 * stage of all the specified scripts
 */
void scripting_init(struct ZorpInvader *zorpinvader);

/**
 * Create the "ZorpInvader" object within the scripting subsystem
 */
void scripting_zorpinvader_init(struct ZorpInvader *zorpinvader);

#endif

