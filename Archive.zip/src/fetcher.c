/*
 * Multi-threaded HTTP fetcher for deep API key scanning.
 *
 * Fetches full page content from discovered open HTTP ports, parses for
 * <script src> tags, fetches referenced JS files from the same IP, and
 * pipes all content through the greyhat API key scanner.
 *
 * Uses raw BSD sockets — no external dependencies.
 */
#include "fetcher.h"
#include "greyhat.h"
#include "massip-addr.h"
#include "util-malloc.h"
#include "pixie-threads.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <zlib.h>
#include <time.h>

#define MAX_QUEUE       65536
#define MAX_FETCH       8       /* max JS files to fetch per host */
#define MAX_BODY        (2*1024*1024)  /* 2MB max page body */
#define FETCH_TIMEOUT   3       /* seconds per HTTP request */
#define RECV_BUF        65536   /* recv buffer size */

/* --- Host queue --- */
struct FetchJob {
    char ip[64];
    unsigned short port;
};

static struct FetchJob job_queue[MAX_QUEUE];
static int q_head = 0, q_tail = 0, q_count = 0;
static pthread_mutex_t q_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  q_cond  = PTHREAD_COND_INITIALIZER;
static int shutdown_flag = 0;

/* --- Stats --- */
static uint64_t stats_pages_fetched = 0;
static uint64_t stats_scripts_fetched = 0;
static uint64_t stats_hosts_scanned = 0;
static uint64_t stats_gzip_bodies = 0;
static uint64_t stats_html_bodies = 0;
static uint64_t stats_script_tag_found = 0;
static uint64_t stats_no_sep = 0;
static uint64_t stats_script_no_src = 0;
static uint64_t stats_script_not_quoted = 0;
static uint64_t stats_script_no_end_quote = 0;
static uint64_t stats_script_no_js = 0;
static uint64_t stats_script_ok = 0;
static uint64_t stats_script_cdn = 0;
static uint64_t stats_script_dnsfail = 0;
static uint64_t stats_script_noslash = 0;
static uint64_t stats_script_fetchfail = 0;
static uint64_t stats_script_fetched = 0;
static uint64_t stats_script_total = 0;

static pthread_mutex_t stats_mutex = PTHREAD_MUTEX_INITIALIZER;

#define STAT_INC(var) do { pthread_mutex_lock(&stats_mutex); (var)++; pthread_mutex_unlock(&stats_mutex); } while(0)

/* --- Deduplication (recent IPs) --- */
#define DEDUP_SIZE 8192
struct DedupEntry {
    char ip[64];
    unsigned short port;
    unsigned valid;
};
static struct DedupEntry dedup_cache[DEDUP_SIZE];
static int dedup_idx = 0;
static pthread_mutex_t dedup_mutex = PTHREAD_MUTEX_INITIALIZER;

static int is_dup(const char *ip, unsigned short port)
{
    pthread_mutex_lock(&dedup_mutex);
    for (int i = 0; i < DEDUP_SIZE; i++) {
        if (dedup_cache[i].valid &&
            strcmp(dedup_cache[i].ip, ip) == 0 &&
            dedup_cache[i].port == port) {
            pthread_mutex_unlock(&dedup_mutex);
            return 1;
        }
    }
    pthread_mutex_unlock(&dedup_mutex);
    return 0;
}

static void add_dedup(const char *ip, unsigned short port)
{
    pthread_mutex_lock(&dedup_mutex);
    int idx = dedup_idx % DEDUP_SIZE;
    strncpy(dedup_cache[idx].ip, ip, 63);
    dedup_cache[idx].ip[63] = '\0';
    dedup_cache[idx].port = port;
    dedup_cache[idx].valid = 1;
    dedup_idx++;
    pthread_mutex_unlock(&dedup_mutex);
}

/* --- DNS cache for script host resolution --- */
#define DNS_CACHE_SIZE 2048
struct DnsEntry {
    char host[256];
    char ip[64];
    unsigned valid;  /* 1=resolved, 2=failed */
};
static struct DnsEntry dns_cache[DNS_CACHE_SIZE];
static int dns_idx = 0;
static pthread_mutex_t dns_mutex = PTHREAD_MUTEX_INITIALIZER;

static const char *dns_cache_lookup(const char *host)
{
    pthread_mutex_lock(&dns_mutex);
    for (int i = 0; i < DNS_CACHE_SIZE; i++) {
        if (dns_cache[i].valid && strcmp(dns_cache[i].host, host) == 0) {
            if (dns_cache[i].valid == 2) {
                pthread_mutex_unlock(&dns_mutex);
                return NULL; /* cached failure */
            }
            static __thread char buf[64];
            strncpy(buf, dns_cache[i].ip, 63);
            buf[63] = '\0';
            pthread_mutex_unlock(&dns_mutex);
            return buf;
        }
    }
    pthread_mutex_unlock(&dns_mutex);
    return NULL; /* not in cache */
}

static void dns_cache_add(const char *host, const char *ip, int success)
{
    pthread_mutex_lock(&dns_mutex);
    int idx = dns_idx % DNS_CACHE_SIZE;
    strncpy(dns_cache[idx].host, host, 255);
    dns_cache[idx].host[255] = '\0';
    if (success && ip) {
        strncpy(dns_cache[idx].ip, ip, 63);
        dns_cache[idx].ip[63] = '\0';
        dns_cache[idx].valid = 1;
    } else {
        dns_cache[idx].valid = 2; /* failed */
    }
    dns_idx++;
    pthread_mutex_unlock(&dns_mutex);
}

/* ---- HTTP fetching using raw sockets ---- */

/**
 * Simple TCP connect + send + recv.
 * Returns body pointer (malloc'd) or NULL on failure.
 * Sets *body_len to body length.
 * Decompresses gzip if Content-Encoding: gzip.
 */
static char *http_get(const char *ip, unsigned short port, const char *path,
                      size_t *body_len, int is_https)
{
    (void)is_https; /* No TLS support yet */
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return NULL;

    struct timeval tv;
    tv.tv_sec = FETCH_TIMEOUT;
    tv.tv_usec = 0;
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    if (inet_pton(AF_INET, ip, &addr.sin_addr) != 1) {
        close(sock);
        return NULL;
    }

    if (connect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(sock);
        return NULL;
    }

    char req[1024];
    int req_len = snprintf(req, sizeof(req),
        "GET %s HTTP/1.0\r\n"
        "Host: %s\r\n"
        "User-Agent: ZorpInvader/1.0\r\n"
        "Accept: */*\r\n"
        "Accept-Encoding: gzip, deflate\r\n"
        "Connection: close\r\n"
        "\r\n",
        path && path[0] ? path : "/", ip);

    if (send(sock, req, req_len, MSG_NOSIGNAL) < 0) {
        close(sock);
        return NULL;
    }

    char *response = MALLOC(MAX_BODY + 1);
    size_t resp_total = 0;
    char recv_buf[RECV_BUF];

    while (resp_total < MAX_BODY) {
        int n = recv(sock, recv_buf, sizeof(recv_buf), 0);
        if (n <= 0) break;
        size_t to_copy = (resp_total + n > MAX_BODY) ? (MAX_BODY - resp_total) : (size_t)n;
        memcpy(response + resp_total, recv_buf, to_copy);
        resp_total += to_copy;
    }
    close(sock);
    response[resp_total] = '\0';

    /* Find end of headers */
    const char *body_start = NULL;
    size_t header_end = 0;
    for (size_t i = 0; i + 3 < resp_total; i++) {
        if (response[i] == '\r' && response[i+1] == '\n' &&
            response[i+2] == '\r' && response[i+3] == '\n') {
            header_end = i + 4;
            body_start = response + header_end;
            break;
        }
    }
    if (!body_start) {
        body_start = response;
        STAT_INC(stats_no_sep);
        header_end = 0;
    }

    size_t body_length = resp_total - header_end;

    /* Check Content-Encoding in headers */
    int is_gzip = 0;
    if (header_end > 0) {
        const char *h = response;
        const char *h_end = response + header_end;
        while (h < h_end - 18) {
            /* Case-insensitive check for Content-Encoding */
            if ((h[0] == 'C' || h[0] == 'c') &&
                (h[1] == 'O' || h[1] == 'o') &&
                (h[2] == 'N' || h[2] == 'n') &&
                (h[3] == 'T' || h[3] == 't') &&
                (h[4] == 'E' || h[4] == 'e') &&
                (h[5] == 'N' || h[5] == 'n') &&
                (h[6] == 'T' || h[6] == 't') &&
                h[7] == '-' &&
                (h[8] == 'E' || h[8] == 'e') &&
                (h[9] == 'N' || h[9] == 'n') &&
                (h[10] == 'C' || h[10] == 'c') &&
                (h[11] == 'O' || h[11] == 'o') &&
                (h[12] == 'D' || h[12] == 'd') &&
                (h[13] == 'I' || h[13] == 'i') &&
                (h[14] == 'N' || h[14] == 'n') &&
                (h[15] == 'G' || h[15] == 'g') &&
                h[16] == ':') {
                const char *val = h + 17;
                while (val < h_end && (*val == ' ' || *val == '\t')) val++;
                if (val + 4 < h_end &&
                    tolower((unsigned char)val[0]) == 'g' &&
                    tolower((unsigned char)val[1]) == 'z' &&
                    tolower((unsigned char)val[2]) == 'i' &&
                    tolower((unsigned char)val[3]) == 'p') {
                    is_gzip = 1;
                STAT_INC(stats_gzip_bodies);
                } else if (val + 7 < h_end &&
                    tolower((unsigned char)val[0]) == 'd' &&
                    tolower((unsigned char)val[1]) == 'e' &&
                    tolower((unsigned char)val[2]) == 'f' &&
                    tolower((unsigned char)val[3]) == 'l' &&
                    tolower((unsigned char)val[4]) == 'a' &&
                    tolower((unsigned char)val[5]) == 't' &&
                    tolower((unsigned char)val[6]) == 'e') {
                    is_gzip = 1; /* deflate uses same inflate logic */
                STAT_INC(stats_gzip_bodies);
                }
                break;
            }
            h++;
        }
    }

    char *body;
    size_t final_len = body_length;

    if (is_gzip && body_length > 0) {
        /* Decompress gzip/deflate using zlib */
        z_stream strm;
        memset(&strm, 0, sizeof(strm));
        /* windowBits=32 for gzip, 15 for deflate, 47 for auto-detect */
        if (inflateInit2(&strm, 47) != Z_OK) {
            body = MALLOC(body_length + 1);
            memcpy(body, body_start, body_length);
            body[body_length] = '\0';
            final_len = body_length;
        } else {
            char *decompressed = MALLOC(MAX_BODY + 1);
            strm.next_in = (unsigned char*)body_start;
            strm.avail_in = (uInt)body_length;
            strm.next_out = (unsigned char*)decompressed;
            strm.avail_out = MAX_BODY;

            int ret = inflate(&strm, Z_FINISH);
            inflateEnd(&strm);

            if (ret == Z_STREAM_END || ret == Z_OK) {
                final_len = MAX_BODY - strm.avail_out;
                body = decompressed;
                body[final_len] = '\0';
            } else {
                /* Decompression failed, use raw body */
                free(decompressed);
                body = MALLOC(body_length + 1);
                memcpy(body, body_start, body_length);
                body[body_length] = '\0';
                final_len = body_length;
            }
        }
    } else {
        body = MALLOC(body_length + 1);
        memcpy(body, body_start, body_length);
        body[body_length] = '\0';
        final_len = body_length;
    }

    free(response);
    *body_len = final_len;
    return body;
}

/* --- HTML script tag parser --- */

/**
 * Parse HTML body for <script src="..."> tags.
 * Returns an array of script paths (malloc'd strings).
 * Sets *count to number of scripts found.
 * Caller must free all strings and the array.
 *
 * Only extracts relative paths (same origin). Absolute URLs to other hosts
 * are skipped to avoid fetching CDN/Cloudflare content.
 */
static char **parse_scripts(const char *body, size_t body_len, int *count)
{
    *count = 0;
    char **scripts = NULL;
    int cap = 0;

    for (size_t i = 0; i + 10 < body_len; i++) {
        /* Look for <script, case-insensitive-ish */
        if (body[i] != '<' && body[i] != 'S' && body[i] != 's') continue;

        const char *p = body + i;
        if (body_len - i < 10) break;

        /* Check for <script (case insensitive for first 7 chars) */
        char tag[8];
        for (int j = 0; j < 7; j++) tag[j] = tolower((unsigned char)p[j]);
        tag[7] = '\0';
        if (strcmp(tag, "<script") != 0) continue;
        STAT_INC(stats_script_total);

        /* Find src= attribute */
        const char *src = NULL;
        for (const char *s = p; s < p + 200 && s < body + body_len; s++) {
            if (*s == '>') break; /* end of tag, no src found */
            /* Look for src= (case insensitive) */
            if (s + 4 < body + body_len &&
                tolower((unsigned char)s[0]) == 's' &&
                tolower((unsigned char)s[1]) == 'r' &&
                tolower((unsigned char)s[2]) == 'c' &&
                s[3] == '=') {
                src = s + 4;
                break;
            }
        }
        if (!src) { STAT_INC(stats_script_no_src); continue; }

        /* Skip whitespace */
        while (*src == ' ' || *src == '\t') src++;

        /* Extract quoted value */
        char quote = *src;
        if (quote != '"' && quote != '\'') { STAT_INC(stats_script_not_quoted); continue; }
        src++;

        const char *end = strchr(src, quote);
        if (!end) { STAT_INC(stats_script_no_end_quote); continue; }

        int path_len = (int)(end - src);
        if (path_len <= 0 || path_len > 1024) continue;

        char *path = strndup(src, path_len);

        /* Note: we keep absolute URLs (https://, //, etc.) now.
         * They get resolved to IPs in the worker, after CDN blocklist check. */

        /* Normalize: strip query string */
        char *qs = strchr(path, '?');
        if (qs) *qs = '\0';

        /* Only fetch JS files */
        if (!strstr(path, ".js") && !strstr(path, ".mjs")) {
            free(path);
            STAT_INC(stats_script_no_js);
            continue;
        }

        /* Add to list */
        if (*count >= cap) {
            cap = cap ? cap * 2 : 8;
            scripts = realloc(scripts, cap * sizeof(char*));
        }
        scripts[*count] = path;
        (*count)++;
        STAT_INC(stats_script_ok);

        if (*count >= MAX_FETCH) break;
    }

    return scripts;
}

/* --- Worker thread --- */

static void *fetcher_worker(void *arg)
{
    (void)arg;

    while (1) {
        struct FetchJob job;

        /* Dequeue */
        pthread_mutex_lock(&q_mutex);
        while (q_count == 0 && !shutdown_flag) {
            pthread_cond_wait(&q_cond, &q_mutex);
        }
        if (shutdown_flag && q_count == 0) {
            pthread_mutex_unlock(&q_mutex);
            break;
        }
        job = job_queue[q_head];
        q_head = (q_head + 1) % MAX_QUEUE;
        q_count--;
        pthread_mutex_unlock(&q_mutex);

        pthread_cond_signal(&q_cond); /* wake throttled enqueuer */
        /* Skip if duplicate */
        if (is_dup(job.ip, job.port)) continue;
        add_dedup(job.ip, job.port);

        /* 1. Fetch the main page */
        size_t body_len = 0;
        char *body = http_get(job.ip, job.port, "/", &body_len, job.port == 443);
        if (!body) {
            STAT_INC(stats_hosts_scanned);
            continue;
        }

        /* Scan the main page for API keys */
        {
            /* Convert IP to ipaddress for greyhat_scan */
            ipaddress ip;
            memset(&ip, 0, sizeof(ip));
            ip.version = 4;
            ip.ipv4 = ntohl(inet_addr(job.ip));
            greyhat_scan(ip, (const unsigned char*)body, (unsigned)body_len);
        }
        STAT_INC(stats_pages_fetched);
        STAT_INC(stats_hosts_scanned);

        /* 2. Parse for script tags */
        /* Check body content type */
        if (body_len > 10 && ((unsigned char)body[0] == 0x1f && (unsigned char)body[1] == 0x8b)) {
            STAT_INC(stats_gzip_bodies); /* still gzip even after decompression attempt */
        }
        if (body_len > 5) {
            int has_html = 0, has_script = 0;
            for (size_t i = 0; i + 10 < body_len; i++) {
                if (strncasecmp(body+i, "<html", 5) == 0 || strncasecmp(body+i, "<!doc", 5) == 0) { has_html = 1; }
                if (strncasecmp(body+i, "<script", 7) == 0) { has_script = 1; }
            }
            if (has_html) STAT_INC(stats_html_bodies);
            if (has_script) STAT_INC(stats_script_tag_found);
        }
        int script_count = 0;
        char **scripts = parse_scripts(body, body_len, &script_count);
        free(body);

        /* 3. Fetch each script and scan (resolve hosts, check CDN blocklist) */
        for (int i = 0; i < script_count; i++) {
            char *script_url = scripts[i];
            char *script_ip = NULL;
            unsigned short script_port = 80;
            const char *script_path = script_url;

            /* Parse the URL to extract host and path */
            char host_buf[256] = {0};
            const char *p = script_url;

            /* Skip protocol (http://, https://, //) */
            if (strstr(p, "://")) {
                const char *sep = strstr(p, "://");
                if (strncmp(p, "https", 5) == 0) {
                    script_port = 443;
                }
                script_path = sep + 3;
            } else if (strncmp(p, "//", 2) == 0) {
                script_path = p + 2;
            } else if (p[0] == '/') {
                /* Relative path starting with / */
                script_ip = strdup(job.ip);
                script_port = job.port;
            }

            /* If we have a host:port/path URL, extract host and path */
            if (script_ip == NULL) {
                /* Find end of host (colon for port or slash for path) */
                const char *host_end = script_path;
                while (*host_end && *host_end != ':' && *host_end != '/') {
                    host_end++;
                }
                int host_len = (int)(host_end - script_path);
                if (host_len <= 0 || host_len > 255) {
                    free(script_url);
                    continue;
                }
                memcpy(host_buf, script_path, host_len);
                host_buf[host_len] = '\0';

                /* CDN / common script repository blocklist */
                int is_blocked = 0;
                static const char *cdn_blocklist[] = {
                    "cloudflare.com", "cdn.cloudflare.net", "cdnjs.cloudflare.com",
                    "unpkg.com", "cdn.jsdelivr.net", "jsdelivr.net",
                    "code.jquery.com", "ajax.googleapis.com", "fonts.googleapis.com",
                    "cdn.jsdelivr.net", "stackpath.bootstrapcdn.com",
                    "maxcdn.bootstrapcdn.com", "cdn.bootcss.com",
                    "kit.fontawesome.com", "use.fontawesome.com",
                    "maps.googleapis.com", "maps.gstatic.com",
                    "www.googletagmanager.com", "www.google-analytics.com",
                    "connect.facebook.net", "connect.facebook.com",
                    "platform.twitter.com", "platform.x.com",
                    "static.cloudflareinsights.com",
                    NULL
                };
                for (int b = 0; cdn_blocklist[b]; b++) {
                    if (strcasecmp(host_buf, cdn_blocklist[b]) == 0) {
                        is_blocked = 1;
                        break;
                    }
                }
                if (is_blocked) {
                    STAT_INC(stats_script_cdn);
                    free(script_url);
                    continue;
                }

                /* DNS cache: check before resolving */
                const char *cached_ip = dns_cache_lookup(host_buf);
                if (cached_ip) {
                    script_ip = strdup(cached_ip);
                    break; /* skip getaddrinfo, use cached IP */
                }

                /* Resolve hostname to IP */
                struct addrinfo hints, *result = NULL;
                memset(&hints, 0, sizeof(hints));
                hints.ai_family = AF_INET;
                hints.ai_socktype = SOCK_STREAM;
                if (getaddrinfo(host_buf, NULL, &hints, &result) != 0) {
                    STAT_INC(stats_script_dnsfail);
                    dns_cache_add(host_buf, NULL, 0); /* cache failure */
                    free(script_url);
                    continue;
                }

                char ip_str[64] = {0};
                struct sockaddr_in *sa = (struct sockaddr_in *)result->ai_addr;
                inet_ntop(AF_INET, &sa->sin_addr, ip_str, sizeof(ip_str));
                freeaddrinfo(result);
                dns_cache_add(host_buf, ip_str, 1); /* cache success */

                /* Find path component */
                const char *slash = strchr(script_path, '/');
                if (!slash) {
                    STAT_INC(stats_script_noslash);
                    free(script_url);
                    continue;
                }
                script_path = slash; /* e.g. "/path/to/script.js" */

                script_ip = strdup(ip_str);
            }

            /* Fetch the script from the resolved IP */
            size_t js_len = 0;
            char *js_body = http_get(script_ip, script_port, script_path,
                                     &js_len, script_port == 443);
            free(script_ip);
            if (js_body && js_len > 0) {
                ipaddress ip;
                memset(&ip, 0, sizeof(ip));
                ip.version = 4;
                ip.ipv4 = ntohl(inet_addr(job.ip));
                greyhat_scan(ip, (const unsigned char*)js_body, (unsigned)js_len);
                STAT_INC(stats_scripts_fetched);
                STAT_INC(stats_script_fetched);
                free(js_body);
            }
            free(script_url);
        }
        free(scripts);
    }

    return NULL;
}

/* --- Public API --- */

void fetcher_init(void)
{
    int ncpus = pixie_cpu_get_count() * 4;
    if (ncpus < 1) ncpus = 1;
    if (ncpus > 256) ncpus = 256; /* Cap to avoid insane thread counts */

    memset(dedup_cache, 0, sizeof(dedup_cache));

    /* Create worker threads */
    for (int i = 0; i < ncpus; i++) {
        pthread_t tid;
        pthread_attr_t attr;
        pthread_attr_init(&attr);
        pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
        if (pthread_create(&tid, &attr, fetcher_worker, NULL) != 0) {
            fprintf(stderr, "[-] fetcher: failed to create worker thread %d\n", i);
        }
        pthread_attr_destroy(&attr);
    }

    fprintf(stderr, "[+] fetcher: started %d worker threads\n", ncpus);
}

void fetcher_enqueue(const char *ip_str, unsigned short port)
{
    pthread_mutex_lock(&q_mutex);
    if (q_count >= MAX_QUEUE) {
        /* Queue full, drop oldest (or drop this one) */
        pthread_mutex_unlock(&q_mutex);
        return;
    }
    job_queue[q_tail].port = port;
    strncpy(job_queue[q_tail].ip, ip_str, sizeof(job_queue[q_tail].ip) - 1);
    job_queue[q_tail].ip[sizeof(job_queue[q_tail].ip) - 1] = '\0';
    q_tail = (q_tail + 1) % MAX_QUEUE;
    q_count++;
    pthread_cond_signal(&q_cond);
    pthread_mutex_unlock(&q_mutex);
}

void fetcher_shutdown(void)
{
    pthread_mutex_lock(&q_mutex);
    shutdown_flag = 1;
    pthread_cond_broadcast(&q_cond);
    pthread_mutex_unlock(&q_mutex);

    /* Give workers a moment to finish in-flight requests */
    usleep(500000);
}

uint64_t fetcher_pages_fetched(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_pages_fetched;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_scripts_fetched(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_scripts_fetched;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_hosts_scanned(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_hosts_scanned;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_gzip_bodies(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_gzip_bodies;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_html_bodies(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_html_bodies;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_script_tags_found(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_script_tag_found;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_no_sep(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_no_sep;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_script_total(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_script_total;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_script_no_src(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_script_no_src;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_script_not_quoted(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_script_not_quoted;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_script_no_end_quote(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_script_no_end_quote;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_script_no_js(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_script_no_js;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_script_ok(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_script_ok;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_script_cdn(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_script_cdn;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_script_dnsfail(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_script_dnsfail;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_script_noslash(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_script_noslash;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_script_fetched(void)
{
    pthread_mutex_lock(&stats_mutex);
    uint64_t v = stats_script_fetched;
    pthread_mutex_unlock(&stats_mutex);
    return v;
}

uint64_t fetcher_queue_depth(void)
{
    pthread_mutex_lock(&q_mutex);
    int v = q_count;
    pthread_mutex_unlock(&q_mutex);
    return (uint64_t)v;
}

/**
 * Throttle: block if queue >= 1000, resume when < 50.
 * Called from receive thread before enqueueing a new host.
 */
#define THROTTLE_HIGH_WATER 1000
#define THROTTLE_LOW_WATER   50

void fetcher_wait_if_throttled(void)
{
    pthread_mutex_lock(&q_mutex);
    while (q_count >= THROTTLE_HIGH_WATER && !shutdown_flag) {
        pthread_cond_wait(&q_cond, &q_mutex);
    }
    pthread_mutex_unlock(&q_mutex);
}
