#ifndef GREYHAT_H
#define GREYHAT_H

#include "massip-addr.h"
#include <stdint.h>

/**
 * Initialize the greyhat suite.
 */
void greyhat_init(void);

/**
 * Scan a banner for API keys.
 */
void greyhat_scan(ipaddress ip, const unsigned char *px, unsigned length);

/**
 * Log a banner discovery to the TUI.
 */
void log_banner(const char *ip, unsigned port, unsigned proto, const char *banner);

#endif
