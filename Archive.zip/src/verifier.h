#ifndef VERIFIER_H
#define VERIFIER_H

/*
 * API key verification via live endpoint checks.
 * Each provider has a verification function that hits the real API
 * using curl (fork+exec) over HTTPS. Returns 1=valid, 0=invalid.
 */

/**
 * Verify a detected API key against the provider's live endpoint.
 * provider: provider string from key_patterns (e.g. "openai", "google")
 * key: the detected key string
 * Returns: 1=valid/live, 0=invalid/dead, -1=unable to check
 */
int verify_api_key(const char *provider, const char *key);

/**
 * Initialize verifier (spawns worker threads).
 * worker_count: number of parallel verification threads (0=auto, typically 4)
 */
void verifier_init(int worker_count);

/**
 * Drain pending verifications and stop workers.
 */
void verifier_shutdown(void);

/**
 * Submit a key for verification. When verified, callback is invoked.
 * ip, key, provider, category are as in the CSV format.
 */
void verifier_submit(const char *ip, const char *key, const char *provider, const char *category);

/**
 * Stats
 */
int verifier_stats_valid(void);
int verifier_stats_invalid(void);
int verifier_stats_pending(void);

#endif

/**
 * Last key status for TUI display
 */
typedef struct {
    char key[512];
    char provider[128];
    char ip[64];
    int confirmed; /* 1=confirmed, 2=detected, 0=rejected */
} LastKeyStatus;

void verifier_get_last_key(LastKeyStatus *out);
