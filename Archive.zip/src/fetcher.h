#ifndef FETCHER_H
#define FETCHER_H

#include <stdint.h>

/**
 * Multi-threaded HTTP fetcher for deep API key scanning.
 *
 * Runs alongside ZorpInvader's port scanner. When an open HTTP port is
 * discovered, it is enqueued here. A thread pool (one worker per CPU core)
 * fetches the full page content, parses for <script src> tags, fetches
 * referenced JS files from the same IP, and pipes all content through
 * the greyhat API key scanner.
 */

/**
 * Initialize the fetcher thread pool. Must be called before any other
 * fetcher function. Creates N worker threads where N = number of CPU cores.
 */
void fetcher_init(void);

/**
 * Enqueue a host for deep scanning. Thread-safe.
 * @param ip_str    IP address as dotted-quad string (e.g. "1.2.3.4")
 * @param port      TCP port number (e.g. 80 or 443)
 *
 * This is called from the banner output path when an open HTTP port is found.
 * The worker threads will:
 *   1. GET / from the host and scan for API keys
 *   2. Parse HTML for <script src="..."> tags pointing to the same IP
 *   3. Fetch each JS file and scan it for API keys
 */
void fetcher_enqueue(const char *ip_str, unsigned short port);

/**
 * Signal all worker threads to shut down and wait for them to finish.
 * Call this at the end of the scan.
 */
void fetcher_shutdown(void);

/**
 * Get statistics (thread-safe snapshots).
 */
uint64_t fetcher_pages_fetched(void);
uint64_t fetcher_scripts_fetched(void);
uint64_t fetcher_hosts_scanned(void);
uint64_t fetcher_queue_depth(void);
uint64_t fetcher_gzip_bodies(void);
uint64_t fetcher_html_bodies(void);
uint64_t fetcher_script_tags_found(void);
uint64_t fetcher_no_sep(void);
uint64_t fetcher_script_total(void);
uint64_t fetcher_script_no_src(void);
uint64_t fetcher_script_not_quoted(void);
uint64_t fetcher_script_no_end_quote(void);
uint64_t fetcher_script_no_js(void);
uint64_t fetcher_script_ok(void);
uint64_t fetcher_script_cdn(void);
uint64_t fetcher_script_dnsfail(void);
uint64_t fetcher_script_noslash(void);
uint64_t fetcher_script_fetched(void);

/**
 * Block if queue >= 1000, resume when < 50.
 */
void fetcher_wait_if_throttled(void);

#endif
