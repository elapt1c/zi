#include "main-status.h"
#include "pixie-timer.h"
#include "unusedparm.h"
#include "main-globals.h"
#include "util-safefunc.h"
#include "util-bool.h"
#include "fetcher.h"
#include "verifier.h"
#include <stdio.h>
#include <string.h>

extern char discovery_log[10][64];
extern char ai_log[10][64];
extern int discovery_log_ptr;
extern int ai_log_ptr;

void status_print(
    struct Status *status,
    uint64_t count,
    uint64_t max_count,
    double pps,
    uint64_t total_tcbs,
    uint64_t total_synacks,
    uint64_t total_syns,
    uint64_t exiting,
    bool json_status)
{
    double elapsed_time;
    double rate;
    double now;
    double percent_done;
    double time_remaining;
    double kpps = pps / 1000;

    global_now = time(0);
    now = (double)pixie_gettime();
    elapsed_time = (now - status->last.clock)/1000000.0;
    if (elapsed_time <= 0) return;

    rate = (count - status->last.count)*1.0/elapsed_time;
    status->last_rates[status->last_count++ & 0x7] = rate;
    rate = 0;
    for (int i=0; i<8; i++) rate += status->last_rates[i];
    rate /= 8;

    percent_done = (double)(count*100.0/max_count);
    time_remaining  = (1.0 - percent_done/100.0) * (max_count / rate);

    // --- TUI DRAWING ---
    // Header
    fprintf(stderr, "\x1b[1;1H\x1b[2K\x1b[44;37m ZorpInvader | Status: %s | Keys: %lu/%lu/%lu \x1b[0m\n", 
        is_tx_done ? "Waiting" : "Scanning", 
        total_keys_found, total_potential_keys, total_sites_checked);

    // Top Bar (Rate/Progress)
    fprintf(stderr, "\x1b[2;1H\x1b[2K \x1b[32mRate:\x1b[0m %6.2f kpps | \x1b[36mProgress:\x1b[0m %5.2f%% | \x1b[33mETA:\x1b[0m %02u:%02u:%02u | \x1b[31mFound:\x1b[0m %lu\n",
        kpps, percent_done, 
        (unsigned)(time_remaining/3600), (unsigned)(time_remaining/60)%60, (unsigned)(time_remaining)%60,
        total_synacks);

    fprintf(stderr, "\x1b[3;1H\x1b[2K\x1b[37m--------------------------------------------------------------------------------\x1b[0m\n");

    // LOG WINDOW HEADERS
    fprintf(stderr, "\x1b[4;1H\x1b[34m[ LIVE SCAN LOG ]\x1b[0m\x1b[4;41H\x1b[35m[  KEY SCAN LOG  ]\x1b[0m\n");
    
    // RENDER LOGS (Last 10)
    for (int i=0; i<10; i++) {
        int d_idx = (discovery_log_ptr + i) % 10;
        int a_idx = (ai_log_ptr + i) % 10;
        
        // Left Column (Discovery)
        fprintf(stderr, "\x1b[%d;1H\x1b[2K %-38s", 5 + i, discovery_log[d_idx]);
        
        // Right Column (AI)
        fprintf(stderr, "\x1b[%d;41H %s\n", 5 + i, ai_log[a_idx]);
    }

    fprintf(stderr, "\x1b[15;1H\x1b[2K\x1b[37m--------------------------------------------------------------------------------\x1b[0m\n");

    // SYSTEM STATUS
    uint64_t now_time = (uint64_t)time(0);
    int content_fresh = (now_time - last_html_time) < 10;
    
    uint64_t fetched = fetcher_pages_fetched();
    uint64_t scripts = fetcher_scripts_fetched();
    uint64_t qdepth = fetcher_queue_depth();
    uint64_t gzip = fetcher_gzip_bodies();
    uint64_t html = fetcher_html_bodies();
    uint64_t script_tag = fetcher_script_tags_found();
    uint64_t no_sep = fetcher_no_sep();

    uint64_t st = fetcher_script_total();
    uint64_t sns = fetcher_script_no_src();
    uint64_t snq = fetcher_script_not_quoted();
    uint64_t sene = fetcher_script_no_end_quote();
    uint64_t snj = fetcher_script_no_js();
    uint64_t sok = fetcher_script_ok();

    uint64_t scdn = fetcher_script_cdn();
    uint64_t sdns = fetcher_script_dnsfail();
    uint64_t snslash = fetcher_script_noslash();
    uint64_t sfetched = fetcher_script_fetched();

    fprintf(stderr, "\x1b[16;1H\x1b[2K\x1b[36mFetcher:\x1b[0m %lu pages, %lu scripts | \x1b[35mgzip=%lu html=%lu <script>=%lu | \x1b[37mcdn=%lu dnsfail=%lu noslash=%lu script_fetched=%lu\n",
        fetched, scripts, gzip, html, script_tag, scdn, sdns, snslash, sfetched);
    
    fprintf(stderr, "\x1b[17;1H\x1b[2K\x1b[37m--------------------------------------------------------------------------------\x1b[0m\n");

    /* --- Last key status --- */
    LastKeyStatus lk;
    verifier_get_last_key(&lk);
    if (lk.confirmed > 0) {
        const char *status_color, *status_label;
        if (lk.confirmed == 1) {
            status_color = "\x1b[32m"; /* green */
            status_label = "CONFIRMED";
        } else {
            status_color = "\x1b[33m"; /* yellow - detected but unverifiable */
            status_label = "DETECTED";
        }
        /* Truncate key for display */
        char short_key[48];
        int klen = (int)strlen(lk.key);
        if (klen > 44) {
            snprintf(short_key, sizeof(short_key), "%.20s...%.20s", lk.key, lk.key + klen - 20);
        } else {
            strncpy(short_key, lk.key, sizeof(short_key) - 1);
            short_key[sizeof(short_key) - 1] = '\0';
        }
        fprintf(stderr, "\x1b[18;1H\x1b[2K [%s%s\x1b[0m] %s | %s | from %s\n",
            status_color, status_label, short_key, lk.provider, lk.ip);
    } else if (lk.confirmed == 0) {
        char short_key[48];
        int klen = (int)strlen(lk.key);
        if (klen > 44) {
            snprintf(short_key, sizeof(short_key), "%.20s...%.20s", lk.key, lk.key + klen - 20);
        } else {
            strncpy(short_key, lk.key, sizeof(short_key) - 1);
            short_key[sizeof(short_key) - 1] = '\0';
        }
        fprintf(stderr, "\x1b[18;1H\x1b[2K [\x1b[31mREJECTED\x1b[0m] %s | %s | from %s\n",
            short_key, lk.provider, lk.ip);
    }

    fflush(stderr);

    status->last.clock = now;
    status->last.count = count;
}

void status_finish(struct Status *status) {
    (void)status;
    fprintf(stderr, "\nScan Complete.\n");
}

void status_start(struct Status *status) {
    memset(status, 0, sizeof(*status));
    status->last.clock = clock();
    status->last.time = time(0);
    status->last.count = 0;
    status->timer = 0x1;
    fprintf(stderr, "\x1b[2J"); 
}
