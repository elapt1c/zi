#ifndef MAIN_GLOBALS_H
#define MAIN_GLOBALS_H
#include <time.h>
#include <stdint.h>

extern unsigned volatile is_tx_done;
extern unsigned volatile is_rx_done;
extern time_t global_now;

extern uint64_t total_keys_found;
extern uint64_t total_potential_keys;
extern uint64_t total_sites_checked;
extern uint64_t total_html_sites;
extern uint64_t last_html_time;

#endif
